package org.tukorea.com.grad.backend.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // 1. CSRF 보안 끄기 (API 서버는 보통 끔)
            .csrf(AbstractHttpConfigurer::disable)

            // 2. 세션 끄기 (나중에 JWT 쓸 거라서)
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // 3. 특정 주소 허용 (나머지는 다 막음)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**").permitAll() // 회원가입, 로그인은 누구나 접속 가능
                .anyRequest().authenticated() // 그 외에는 로그인해야 가능
            );
        
        return http.build();
    }
}