package org.tukorea.com.grad.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradBackendApplication.class, args);
	}

}
