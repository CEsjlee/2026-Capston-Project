package org.tukorea.com.grad.backend.entity;

public enum Role {
	USER, ADMIN
}

    