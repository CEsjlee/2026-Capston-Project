package org.tukorea.com.grad.backend.jwt;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtTokenProvider {

    // 1. 비밀키 (원래는 properties 파일에 숨겨야 하지만, 일단 여기 적습니다)
    // 주의: 32글자 이상이어야 에러가 안 납니다. 절대 줄이지 마세요!
    private final String SECRET_KEY = "mySuperSecretKeyForGraduationProjectDoNotHackMePlease";
    
    // 암호화 키 객체 생성
    private final Key key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes());

    // 2. 토큰 유효 시간 (30분 = 1000 * 60 * 30)
    private final long TOKEN_VALID_TIME = 1000L * 60 * 30;

    // 3. 토큰 생성 기능 (로그인 성공 시 호출)
    // [변경 1] 괄호 안에 String name 을 추가
    public String createToken(String email, String role, String name) { 
        
        Claims claims = Jwts.claims().setSubject(email); // 이메일 저장
        claims.put("role", role); // 권한 저장
        
        // [변경 2] 여기에 이름을 저장하는 코드를 추가
        claims.put("name", name); 

        Date now = new Date();
        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(new Date(now.getTime() + TOKEN_VALID_TIME))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }
    
    // (나중에 토큰 검증 기능도 여기에 추가될 예정)
}