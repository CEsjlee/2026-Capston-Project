import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Onboarding from './pages/Onboarding';
import Layout from './components/Layout'; 
import Roadmap from './pages/Roadmap';
import Activity from './pages/Activity';
import Collaboration from './pages/Collaboration';
import Portfolio from './pages/Portfolio';
import Note from './pages/Note';
import Feedback from './pages/Feedback';
import Settings from './pages/Settings';

function App() {
  return (
    <Routes>
      
      <Route path="/" element={<Navigate to="/login" />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/onboarding" element={<Onboarding />} />

      
      <Route element={<Layout />}>
        <Route path="/roadmap" element={<Roadmap />} />
        <Route path="/activity" element={<Activity />} />
        <Route path="/collaboration" element={<Collaboration />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/note" element={<Note />} />
        <Route path="/feedback" element={<Feedback />} />
        <Route path="/settings" element={<Settings />} />
      </Route>
    </Routes>
  );
}

export default App;