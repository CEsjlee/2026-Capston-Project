import axios from 'axios';

// 1. 주소 변경 (중요!)
// 이제 http://localhost:8080을 직접 안 쓰고, '/api'라고만 쓰면
// vite.config.js에 설정한 프록시가 알아서 백엔드로 연결해줍니다.
const BASE_URL = '/api'; 

const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 2. 요청 인터셉터 추가 (토큰 자동 첨부)
// API 요청을 보낼 때마다 "가로채서" 토큰이 있는지 검사하고, 있으면 헤더에 넣어줍니다.
api.interceptors.request.use(
  (config) => {
    // 로컬 스토리지에서 토큰 꺼내기
    const token = localStorage.getItem('accessToken');

    // 토큰이 있다면 헤더에 'Bearer 토큰' 형식으로 추가
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default api;