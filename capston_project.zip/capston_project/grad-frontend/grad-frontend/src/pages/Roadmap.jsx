import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

const Roadmap = () => {
  const navigate = useNavigate();
  const [showContent, setShowContent] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const hasSetup = localStorage.getItem('hasSetup');
    if (hasSetup === 'true') {
      setShowContent(true);
    } else {
      setShowContent(false);
      setShowPopup(true);
    }
  }, []);

  // 더미 데이터
  const dummyData = {
    interest: "백엔드 개발자",
    
    // 학기별 더미 데이터 배열
    semesterPlans: [
      {
        grade: "1학년 1학기",
        status: "completed", 
        goal: ["학점 3.5 이상", "C언어 기초 마스터"],
        courses: ["C프로그래밍", "대학수학", "글쓰기"],
        activities: ["컴퓨터 동아리 가입"]
      },
      {
        grade: "1학년 2학기",
        status: "completed",
        goal: ["자료구조 선행 학습", "웹 개발 맛보기"],
        courses: ["심화 C프로그래밍", "이산수학", "웹기초"],
        activities: ["IT 컨퍼런스 참관"]
      },
      {
        grade: "2학년 1학기",
        status: "completed",
        goal: ["자료구조 A+ 맞기", "Java 문법 익히기"],
        courses: ["자료구조", "객체지향프로그래밍", "컴퓨터구조"],
        activities: ["알고리즘 스터디 시작"]
      },
      {
        grade: "2학년 2학기",
        status: "completed",
        goal: ["알고리즘 문제 해결 능력 키우기"],
        courses: ["알고리즘", "데이터베이스", "리눅스실습"],
        activities: ["백준 실버 달성"]
      },
      {
        grade: "3학년 1학기",
        status: "current",
        goal: ["운영체제 A+ 맞기", "Spring Boot 입문"],
        courses: ["운영체제", "컴퓨터 네트워크", "DB응용"],
        activities: ["멋쟁이사자처럼 12기", "1일 1커밋"]
      },
      {
        grade: "3학년 2학기",
        status: "future",
        goal: ["캡스톤 디자인 기획", "인턴 지원하기"],
        courses: ["소프트웨어공학", "인공지능", "분산시스템"],
        activities: ["해커톤 참여", "토익 850점"]
      },
      {
        grade: "4학년 1학기",
        status: "future",
        goal: ["졸업작품 중간 발표", "정보처리기사 취득"],
        courses: ["캡스톤디자인(1)", "클라우드컴퓨팅", "정보보안"],
        activities: ["취업 포트폴리오 완성"]
      },
      {
        grade: "4학년 2학기",
        status: "future",
        goal: ["최종 취업 성공", "졸업작품 완성"],
        courses: ["캡스톤디자인(2)", "진로세미나"],
        activities: ["면접 스터디", "최종 합격"]
      }
    ],

    companies: [
      { name: "네이버", role: "백엔드", stack: ["Java", "Spring"], gpa: "3.8" },
      { name: "카카오", role: "서버", stack: ["Kotlin", "JPA"], gpa: "3.7" },
      { name: "라인", role: "글로벌", stack: ["Java", "Redis"], gpa: "3.6" }
    ],
    gaps: {
      owned: ["Java", "Python", "Git", "MySQL"],
      missing: [
        { name: "Redis", method: "인프런 강의 수강" },
        { name: "Docker", method: "개인 프로젝트 배포 실습" },
        { name: "AWS", method: "클라우드 자격증 준비" }
      ]
    }
  };

  return (
    <MainContent>
      {showContent ? (
        <>
          <PageHeader>
            <PageTitle>진로 로드맵</PageTitle>
            <TopButton>🔄 로드맵 최신화</TopButton>
          </PageHeader>

          <GoalSection>
            <GoalTitle>🎯 목표 직군</GoalTitle>
            <GoalText>{dummyData.interest}</GoalText>
          </GoalSection>

          <SectionTitle>📅 학기별 성장 로드맵</SectionTitle>
          
          {/* 👇 [변경됨] 가로 스크롤 컨테이너 시작 */}
          <ScrollContainer>
            {dummyData.semesterPlans.map((sem, index) => (
              <RoadmapCard key={index} status={sem.status}>
                <CardHeader>
                  <CardHeaderBadge status={sem.status}>{index + 1}</CardHeaderBadge>
                  <CardTitle>{sem.grade}</CardTitle>
                  {sem.status === 'current' && <CurrentBadge>현재</CurrentBadge>}
                </CardHeader>
                
                {/* 내부 내용은 세로로 쌓음 */}
                <CardInnerStack>
                  <InfoBlock>
                    <SubHeader>◎ 학습 목표</SubHeader>
                    <List>
                      {sem.goal.map((t, i) => <li key={i}>{t}</li>)}
                    </List>
                  </InfoBlock>
                  
                  <InfoBlock>
                    <SubHeader>추천 수강 과목</SubHeader>
                    <SubjectWrap>
                      {sem.courses.map((t, i) => <SubjectBadge key={i}>{t}</SubjectBadge>)}
                    </SubjectWrap>
                  </InfoBlock>

                  <InfoBlock>
                    <SubHeader>추천 활동</SubHeader>
                    <List check>
                      {sem.activities.map((t, i) => <li key={i}>{t}</li>)}
                    </List>
                  </InfoBlock>
                </CardInnerStack>
              </RoadmapCard>
            ))}
          </ScrollContainer>
          {/* 👆 가로 스크롤 컨테이너 끝 */}

          <SectionTitle>🏢 목표 기업 정보</SectionTitle>
          <CompanyGrid>
            {dummyData.companies.map((c, i) => (
              <CompanyCard key={i}>
                <h3>{c.name}</h3><p>{c.role}</p>
                <TagContainer>{c.stack.map((s,j)=><Tag key={j}>{s}</Tag>)}</TagContainer>
                <StatRow><span>평균 학점</span><strong>{c.gpa}</strong></StatRow>
              </CompanyCard>
            ))}
          </CompanyGrid>

          <SectionTitle>📈 역량 격차 분석</SectionTitle>
          <GapCard>
            <GapGrid>
              <div>
                <GapHeader className="green">● 보유 역량</GapHeader>
                <p style={{color: '#555', fontSize: '15px', lineHeight: '1.6'}}>
                   {dummyData.gaps.owned.join(', ')}
                </p>
              </div>
              <div>
                <GapHeader className="orange">● 부족 역량 (보완 필요)</GapHeader>
                {dummyData.gaps.missing.map((item, i) => (
                  <GapItem key={i}>
                    <strong>{item.name}</strong>
                    <span>추천 학습: {item.method}</span>
                  </GapItem>
                ))}
              </div>
            </GapGrid>
            <AiFeedback>
              <strong>💡 AI 학습 조언</strong>
              <p>현재 <strong>{dummyData.interest}</strong>를 목표로 하기에 <strong>클라우드(AWS)</strong>와 <strong>컨테이너(Docker)</strong> 경험이 부족합니다.</p>
            </AiFeedback>
          </GapCard>

          <FooterSpacer />
        </>
      ) : (
        <EmptyStateMessage>
           아직 로드맵이 없습니다.<br/>프로필을 설정해주세요.
        </EmptyStateMessage>
      )}

      {/* 팝업 모달 */}
      {showPopup && (
        <Overlay>
          <DialogBox>
            <DialogIcon>⚠️</DialogIcon>
            <DialogTitle>프로필 설정이 필요합니다</DialogTitle>
            <DialogText>맞춤형 로드맵을 위해<br />프로필 정보를 입력해주세요.</DialogText>
            <DialogButtonGroup>
              <DialogButton secondary onClick={() => setShowPopup(false)}>나중에</DialogButton>
              <DialogButton primary onClick={() => navigate('/onboarding')}>지금 설정하기</DialogButton>
            </DialogButtonGroup>
          </DialogBox>
        </Overlay>
      )}
    </MainContent>
  );
};

export default Roadmap;

// 스타일 컴포넌트

const MainContent = styled.div` flex: 1; padding: 40px; overflow-y: auto; height: 100vh; box-sizing: border-box;`;
const PageHeader = styled.div` display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; `;
const PageTitle = styled.h2` font-size: 24px; color: #333; font-weight: bold; `;
const TopButton = styled.button` background: #a855f7; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; cursor: pointer; `;

// 목표 섹션
const GoalSection = styled.div` background: #fdf4ff; border: 1px solid #f0abfc; padding: 20px; border-radius: 12px; margin-bottom: 40px; `;
const GoalTitle = styled.h4` color: #a855f7; margin-bottom: 5px; `;
const GoalText = styled.div` font-size: 18px; font-weight: bold; color: #333; `;

const ScrollContainer = styled.div`
  display: flex;
  gap: 20px;
  overflow-x: auto;
  padding-bottom: 20px; /* 스크롤바 공간 확보 */
  margin-bottom: 40px;
  
  /* 스크롤바 디자인 (선택사항) */
  &::-webkit-scrollbar { height: 8px; }
  &::-webkit-scrollbar-thumb { background: #ddd; border-radius: 4px; }
  &::-webkit-scrollbar-track { background: transparent; }
`;

const RoadmapCard = styled.div`
  min-width: 320px; /* 카드의 최소 너비 고정  */
  background: white;
  padding: 25px;
  border-radius: 16px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.05);
  border: 1px solid ${props => props.status === 'current' ? '#a855f7' : '#eee'}; /* 현재 학기 강조 */
  display: flex;
  flex-direction: column;
  position: relative;
  
  /* 미래 학기는 약간 흐리게 */
  opacity: ${props => props.status === 'future' ? 0.7 : 1};
`;

const CardHeader = styled.div` display: flex; align-items: center; gap: 10px; margin-bottom: 20px; border-bottom: 1px solid #f0f0f0; padding-bottom: 15px; `;
const CardHeaderBadge = styled.div` 
  width: 28px; height: 28px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: bold; font-size: 14px;
  background: ${props => props.status === 'current' ? '#a855f7' : '#eee'};
  color: ${props => props.status === 'current' ? 'white' : '#666'};
`;
const CardTitle = styled.h4` font-size: 18px; margin: 0; flex: 1; `;
const CurrentBadge = styled.span` background: #f3e8ff; color: #7e22ce; font-size: 11px; padding: 4px 8px; border-radius: 12px; font-weight: bold; `;

// 카드 내부 내용을 세로로 보여줌
const CardInnerStack = styled.div` display: flex; flex-direction: column; gap: 20px; `;
const InfoBlock = styled.div``;
const SubHeader = styled.h5` font-size: 14px; color: #666; margin-bottom: 10px; font-weight: bold; `;
const SubjectWrap = styled.div` display: flex; gap: 5px; flex-wrap: wrap; `;

const List = styled.ul` 
  padding-left: 20px; margin: 0; 
  li { margin-bottom: 6px; color: #444; font-size: 13px; line-height: 1.5; } 
  ${props => props.check && `list-style: none; padding-left: 0; li:before { content: '✓ '; color: #ec4899; font-weight: bold; margin-right: 5px; }`} 
`;
const SubjectBadge = styled.div` background: #f8f9fa; padding: 8px 12px; border-radius: 6px; font-size: 13px; color: #555; text-align: center; border: 1px solid #eee; `;

// 나머지 스타일 (기업정보, 역량분석 등)
const SectionTitle = styled.h3` font-size: 18px; color: #333; margin: 0 0 20px 0; display: flex; align-items: center; gap: 8px; `;
const CompanyGrid = styled.div` display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; `;
const CompanyCard = styled.div` background: white; padding: 25px; border-radius: 16px; border: 1px solid #eee; h3 { margin-bottom: 5px; } p { color: #888; font-size: 14px; margin-bottom: 15px; } `;
const TagContainer = styled.div` display: flex; gap: 5px; flex-wrap: wrap; margin-bottom: 20px; `;
const Tag = styled.span` background: #f3e8ff; color: #7e22ce; padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; `;
const StatRow = styled.div` display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 8px; span { color: #888; } strong { color: #333; } `;
const GapCard = styled.div` background: white; padding: 30px; border-radius: 16px; border: 1px solid #eee; `;
const GapGrid = styled.div` display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 30px; `;
const GapHeader = styled.h5` margin-bottom: 15px; display: flex; align-items: center; gap: 8px; &.green { color: #22c55e; } &.orange { color: #f97316; } `;
const GapItem = styled.div` margin-bottom: 15px; strong { display: block; font-size: 15px; margin-bottom: 4px; color: #333; } span { font-size: 12px; color: #888; } `;
const AiFeedback = styled.div` background: #fdf4ff; padding: 20px; border-radius: 12px; strong { color: #a855f7; display: block; margin-bottom: 8px; } p { color: #555; font-size: 14px; margin: 0; line-height: 1.5; } `;
const EmptyStateMessage = styled.div` display: flex; justify-content: center; align-items: center; height: 100%; color: #aaa; font-size: 16px; text-align: center; line-height: 1.6;`;
const Overlay = styled.div` position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); display: flex; justify-content: center; align-items: center; z-index: 1000; `;
const DialogBox = styled.div` background: white; padding: 30px; border-radius: 16px; width: 400px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,0.2); animation: popUp 0.3s ease-out; @keyframes popUp { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } } `;
const DialogIcon = styled.div` font-size: 40px; margin-bottom: 15px; `;
const DialogTitle = styled.h3` margin: 0 0 10px 0; color: #333; font-size: 20px; `;
const DialogText = styled.p` color: #666; margin-bottom: 30px; line-height: 1.5; `;
const DialogButtonGroup = styled.div` display: flex; gap: 10px; justify-content: center; `;
const DialogButton = styled.button` flex: 1; padding: 12px; border-radius: 8px; font-weight: bold; cursor: pointer; border: none; font-size: 14px; background: ${props => props.primary ? '#a855f7' : '#f3f4f6'}; color: ${props => props.primary ? 'white' : '#666'}; &:hover { opacity: 0.9; } `;
const FooterSpacer = styled.div` height: 50px; `;