import { useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import Input from '../components/Input';

const Onboarding = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const totalSteps = 5;

  // UI 동작을 위한 임시 상태 (DB 저장용 아님, 화면에서 글씨 써지는 것 보여주기용)
  const [formData, setFormData] = useState({
    grade: '', major: '', interest: '', courses: [], projects: '', gpa: '', language: '', partTime: '', internship: '', certificates: ''
  });

  const [courseInput, setCourseInput] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const addCourse = () => {
    if (courseInput.trim() === '') return;
    setFormData({ ...formData, courses: [...formData.courses, courseInput] });
    setCourseInput('');
  };

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);
  
  // [핵심 로직] 설정 완료 시 '도장'만 찍고 로드맵으로 이동
  const handleComplete = (isSkipped = false) => {
    // 1. "설정 완료했음" 표시 남기기
    localStorage.setItem('hasSetup', 'true');

    // 2. 메시지 띄우고 이동
    if (isSkipped) {
      alert("설정을 건너뛰었습니다. (가상 데이터가 표시됩니다)");
    } else {
      alert("프로필 설정 완료! (가상 데이터가 표시됩니다)");
    }
    navigate('/roadmap');
  };

  return (
    <Container>
      <Card>
        <Header>
          <Title>프로필 설정</Title>
          <ProgressBarContainer><Progress width={(step / totalSteps) * 100} /></ProgressBarContainer>
          <StepCount>{step} / {totalSteps}</StepCount>
          <SubText>
            AI 맞춤 로드맵을 위한 정보를 입력해주세요.<br/>
            (시연을 위해 입력하는 척만 하셔도 됩니다)
          </SubText>
        </Header>
        
        <Content>
          {/* --- Step 1: 기본 정보 --- */}
          {step === 1 && (
            <>
              <h3>기본 정보</h3>
              <Label>학년</Label>
              <Select name="grade" value={formData.grade} onChange={handleChange}>
                <option value="">선택하세요</option><option value="1학년">1학년</option><option value="2학년">2학년</option><option value="3학년">3학년</option><option value="4학년">4학년</option>
              </Select>
              <Input label="전공" name="major" placeholder="예: 컴퓨터공학과" value={formData.major} onChange={handleChange} />
              <Input label="관심 진로" name="interest" placeholder="예: 백엔드 개발자" value={formData.interest} onChange={handleChange} />
            </>
          )}

          {/* --- Step 2: 수강 과목 --- */}
          {step === 2 && (
            <>
              <h3>수강 과목</h3>
              <InputGroup>
                <Input label="과목명" placeholder="예: 자료구조" value={courseInput} onChange={(e) => setCourseInput(e.target.value)} />
                <AddButton onClick={addCourse}>추가</AddButton>
              </InputGroup>
              <TagsArea>{formData.courses.map((c, i) => <Tag key={i}>#{c}</Tag>)}</TagsArea>
            </>
          )}

          {/* --- Step 3: 프로젝트 --- */}
          {step === 3 && (
            <>
              <h3>프로젝트 경험</h3>
              <TextArea name="projects" placeholder="프로젝트 경험 입력" value={formData.projects} onChange={handleChange} />
            </>
          )}

          {/* --- Step 4: 성적 --- */}
          {step === 4 && (
            <>
              <h3>성적 정보</h3>
              <Input label="학점" name="gpa" placeholder="4.5" value={formData.gpa} onChange={handleChange} />
              <Input label="어학" name="language" placeholder="TOEIC 900" value={formData.language} onChange={handleChange} />
            </>
          )}

           {/* --- Step 5: 자격증 --- */}
           {step === 5 && (
            <>
              <h3>경험 및 자격증</h3>
              <TextArea name="certificates" placeholder="자격증 입력" value={formData.certificates} onChange={handleChange} />
            </>
          )}
        </Content>

        <Footer>
          {step > 1 ? <NavButton onClick={prevStep}>이전</NavButton> : <div></div>}
          <RightButtons>
            {step < totalSteps ? (
              <>
                <MainButton onClick={nextStep}>다음</MainButton>
                <SkipButton onClick={() => handleComplete(true)}>건너뛰기</SkipButton>
              </>
            ) : (
               <>
                <MainButton onClick={() => handleComplete(false)}>설정 완료</MainButton>
                <SkipButton onClick={() => handleComplete(true)}>건너뛰고 완료</SkipButton>
               </>
            )}
          </RightButtons>
        </Footer>
      </Card>
    </Container>
  );
};

export default Onboarding;

// 스타일 컴포넌트
const Container = styled.div` background-color: #f5f7fa; min-height: 100vh; display: flex; justify-content: center; align-items: center; `;
const Card = styled.div` background: white; width: 600px; padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); `;
const Header = styled.div` margin-bottom: 20px; `;
const Title = styled.h2` color: #a855f7; margin: 0 0 20px 0; font-size: 20px; font-weight: bold; `;
const SubText = styled.p` color: #333; font-size: 14px; margin-top: 10px; color: #666; line-height: 1.5; `;
const ProgressBarContainer = styled.div` width: 100%; height: 4px; background: #eee; border-radius: 2px; overflow: hidden; display: flex; `;
const Progress = styled.div` width: ${props => props.width}%; height: 100%; background: #333; transition: width 0.3s ease; `;
const StepCount = styled.div` text-align: right; font-size: 14px; color: #999; margin-top: 8px; `;
const Content = styled.div` min-height: 350px; margin-top: 30px; h3 { font-size: 18px; color: #111; margin-bottom: 25px; font-weight: bold; }`;
const Select = styled.select` width: 100%; padding: 14px; background-color: #f3f4f6; border: 1px solid transparent; border-radius: 8px; font-size: 14px; outline: none; margin-bottom: 20px; `;
const Label = styled.label` display: block; margin-bottom: 8px; font-size: 14px; color: #666; font-weight: 500; margin-top: 15px;`;
const TextArea = styled.textarea` width: 100%; padding: 14px; background-color: #f3f4f6; border: 1px solid transparent; border-radius: 8px; font-size: 14px; outline: none; resize: none; height: 120px; `;
const InputGroup = styled.div` display: flex; align-items: flex-end; gap: 10px; `;
const AddButton = styled.button` height: 46px; padding: 0 20px; margin-bottom: 20px; background: #fff; border: 1px solid #ddd; color: #333; border-radius: 8px; cursor: pointer; `;
const TagsArea = styled.div` display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; `;
const Tag = styled.span` background: #f3e8ff; color: #7e22ce; padding: 6px 12px; border-radius: 20px; font-size: 13px; font-weight: bold; `;
const Footer = styled.div` display: flex; justify-content: space-between; align-items: center; margin-top: 40px; border-top: 1px solid #eee; padding-top: 20px;`;
const RightButtons = styled.div` display: flex; gap: 10px; `;
const NavButton = styled.button` background: white; border: 1px solid #ddd; padding: 10px 24px; border-radius: 8px; cursor: pointer; font-weight: 500; color: #666; `;
const MainButton = styled.button` background: linear-gradient(90deg, #a855f7, #d946ef); color: white; border: none; padding: 10px 30px; border-radius: 8px; cursor: pointer; font-weight: bold; `;
const SkipButton = styled.button` background: white; border: 1px solid #ddd; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 500; color: #666; `;