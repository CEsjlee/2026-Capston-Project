import { useState } from 'react';
import styled from 'styled-components';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('profile'); // profile, account, notification

  // 가짜 사용자 정보
  const user = {
    name: "이승주",
    email: "sjlee@naver.com"
  };

  // 체크박스 상태 관리 (알림 탭용)
  const [notif, setNotif] = useState({
    email1: true, email2: true, email3: true,
    app1: true, app2: true, app3: false
  });

  const handleCheck = (key) => {
    setNotif({ ...notif, [key]: !notif[key] });
  };

  const handleLogout = () => {
    if(window.confirm("정말 로그아웃 하시겠습니까?")) {
      localStorage.removeItem('authData');
      window.location.href = '/login';
    }
  };

  return (
    <Container>
      <PageHeader>
        <PageTitle>설정</PageTitle>
        <PageSubtitle>계정 및 프로필 설정을 관리하세요</PageSubtitle>
      </PageHeader>

      <SettingsGrid>
        {/* --- 왼쪽: 서브 메뉴 --- */}
        <LeftMenu>
          <MenuButton 
            active={activeTab === 'profile'} 
            onClick={() => setActiveTab('profile')}
          >
            👤 프로필
          </MenuButton>
          <MenuButton 
            active={activeTab === 'account'} 
            onClick={() => setActiveTab('account')}
          >
            🔒 계정
          </MenuButton>
          <MenuButton 
            active={activeTab === 'notification'} 
            onClick={() => setActiveTab('notification')}
          >
            🔔 알림
          </MenuButton>

          <LogoutButton onClick={handleLogout}>
            [→ 로그아웃
          </LogoutButton>
        </LeftMenu>

        {/* --- 오른쪽: 컨텐츠 영역 --- */}
        <RightContent>
          
          {/* 1. 프로필 설정 탭 */}
          {activeTab === 'profile' && (
            <>
              <ContentHeader>
                <ContentTitle>프로필 정보</ContentTitle>
                <EditButton>📝 프로필 수정</EditButton>
              </ContentHeader>
              
              <SectionTitle>기본 정보</SectionTitle>
              <InputRow>
                <InputGroup>
                  <Label>이름</Label>
                  <ReadOnlyInput value={user.name} readOnly />
                </InputGroup>
                <InputGroup>
                  <Label>이메일</Label>
                  <ReadOnlyInput value={user.email} readOnly />
                </InputGroup>
              </InputRow>

              <EmptyProfileBox>
                <EmptyText>아직 프로필이 설정되지 않았습니다.</EmptyText>
                <PurpleButton>프로필 설정하기</PurpleButton>
              </EmptyProfileBox>
            </>
          )}

          {/* 2. 계정 설정 탭 */}
          {activeTab === 'account' && (
            <>
              <ContentHeader>
                <ContentTitle>계정 설정</ContentTitle>
              </ContentHeader>

              <SectionTitle>이메일</SectionTitle>
              <InputGroup style={{marginBottom: '30px'}}>
                <ReadOnlyInput value={user.email} readOnly />
                <HelperText>이메일은 변경할 수 없습니다.</HelperText>
              </InputGroup>

              <SectionTitle>비밀번호 변경</SectionTitle>
              <InputGroup>
                <Label>현재 비밀번호</Label>
                <StyledInput type="password" placeholder="현재 비밀번호를 입력하세요" />
              </InputGroup>
              <InputGroup>
                <Label>새 비밀번호</Label>
                <StyledInput type="password" placeholder="새 비밀번호를 입력하세요" />
              </InputGroup>
              <InputGroup>
                <Label>새 비밀번호 확인</Label>
                <StyledInput type="password" placeholder="새 비밀번호를 다시 입력하세요" />
              </InputGroup>
              
              <PurpleButton style={{width: 'fit-content', marginTop: '10px'}}>비밀번호 변경</PurpleButton>

              <Divider />

              <SectionTitle style={{color: '#ef4444'}}>계정 삭제</SectionTitle>
              <HelperText>계정을 삭제하면 모든 데이터가 영구적으로 삭제되며 복구할 수 없습니다.</HelperText>
              <DeleteButton>계정 삭제</DeleteButton>
            </>
          )}

          {/* 3. 알림 설정 탭 */}
          {activeTab === 'notification' && (
            <>
              <ContentHeader>
                <ContentTitle>알림 설정</ContentTitle>
              </ContentHeader>

              <SectionTitle>이메일 알림</SectionTitle>
              <CheckList>
                <CheckItem>
                  <span>로드맵 업데이트 알림</span>
                  <input type="checkbox" checked={notif.email1} onChange={() => handleCheck('email1')} />
                </CheckItem>
                <CheckItem>
                  <span>새로운 활동 추천</span>
                  <input type="checkbox" checked={notif.email2} onChange={() => handleCheck('email2')} />
                </CheckItem>
                <CheckItem>
                  <span>마감 임박 공모전 알림</span>
                  <input type="checkbox" checked={notif.email3} onChange={() => handleCheck('email3')} />
                </CheckItem>
              </CheckList>

              <SectionTitle>앱 내 알림</SectionTitle>
              <CheckList>
                <CheckItem>
                  <span>피드백 알림</span>
                  <input type="checkbox" checked={notif.app1} onChange={() => handleCheck('app1')} />
                </CheckItem>
                <CheckItem>
                  <span>협업툴 메시지 알림</span>
                  <input type="checkbox" checked={notif.app2} onChange={() => handleCheck('app2')} />
                </CheckItem>
                <CheckItem>
                  <span>포트폴리오 AI 추천</span>
                  <input type="checkbox" checked={notif.app3} onChange={() => handleCheck('app3')} />
                </CheckItem>
              </CheckList>

              <PurpleButton style={{width: 'fit-content', marginTop: '30px'}}>알림 설정 저장</PurpleButton>
            </>
          )}

        </RightContent>
      </SettingsGrid>
    </Container>
  );
};

export default Settings;

// 스타일 컴포넌트

const Container = styled.div`
  flex: 1; padding: 40px; overflow-y: auto; height: 100vh; box-sizing: border-box; background-color: #f8f9fc;
`;

const PageHeader = styled.div` margin-bottom: 40px; `;
const PageTitle = styled.h2` font-size: 28px; color: #333; font-weight: bold; margin-bottom: 8px; `;
const PageSubtitle = styled.p` font-size: 16px; color: #666; `;

const SettingsGrid = styled.div` display: flex; gap: 30px; `;


const LeftMenu = styled.div`
  width: 240px; display: flex; flex-direction: column; gap: 10px;
`;
const MenuButton = styled.button`
  width: 100%; padding: 15px 20px; text-align: left; border-radius: 12px; font-size: 15px; font-weight: bold; border: none; cursor: pointer;
  background: ${props => props.active ? 'linear-gradient(90deg, #a855f7, #d946ef)' : 'white'};
  color: ${props => props.active ? 'white' : '#666'};
  box-shadow: ${props => props.active ? '0 4px 10px rgba(168,85,247,0.3)' : 'none'};
  transition: all 0.2s;
  &:hover { transform: translateY(-2px); }
`;
const LogoutButton = styled.button`
  width: 100%; padding: 15px 20px; text-align: left; border-radius: 12px; font-size: 15px; font-weight: bold; border: 1px solid #eee; background: white; color: #ef4444; cursor: pointer; margin-top: 20px;
  &:hover { background: #fef2f2; }
`;


const RightContent = styled.div`
  flex: 1; background: white; border-radius: 16px; padding: 40px; border: 1px solid #eee; min-height: 500px;
`;
const ContentHeader = styled.div` display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; border-bottom: 1px solid #f0f0f0; padding-bottom: 20px; `;
const ContentTitle = styled.h3` font-size: 20px; font-weight: bold; color: #333; `;
const EditButton = styled.button` background: white; border: 1px solid #ddd; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: bold; color: #555; cursor: pointer; &:hover { background: #f9fafb; } `;

const SectionTitle = styled.h4` font-size: 16px; font-weight: bold; color: #333; margin-bottom: 15px; margin-top: 10px; `;
const InputRow = styled.div` display: flex; gap: 20px; margin-bottom: 30px; `;
const InputGroup = styled.div` flex: 1; display: flex; flex-direction: column; gap: 8px; margin-bottom: 20px; `;
const Label = styled.label` font-size: 13px; color: #666; font-weight: 500; `;
const ReadOnlyInput = styled.input` padding: 14px; background: #f9fafb; border: 1px solid #eee; border-radius: 8px; color: #888; font-size: 14px; outline: none; `;
const StyledInput = styled.input` padding: 14px; background: white; border: 1px solid #ddd; border-radius: 8px; color: #333; font-size: 14px; outline: none; &:focus { border-color: #a855f7; } `;
const HelperText = styled.p` font-size: 12px; color: #888; margin-top: -5px; margin-bottom: 20px; `;

const EmptyProfileBox = styled.div` background: #fafafa; border-radius: 12px; padding: 40px; text-align: center; border: 1px dashed #ddd; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 150px; `;
const EmptyText = styled.p` color: #666; font-size: 14px; margin-bottom: 15px; `;

const PurpleButton = styled.button` background: #a855f7; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer; &:hover { background: #9333ea; } `;
const DeleteButton = styled.button` background: white; color: #ef4444; border: 1px solid #ef4444; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer; &:hover { background: #fef2f2; } `;
const Divider = styled.hr` border: none; border-top: 1px solid #eee; margin: 30px 0; `;


const CheckList = styled.div` display: flex; flex-direction: column; gap: 0; background: #f9fafb; border-radius: 8px; overflow: hidden; margin-bottom: 30px; `;
const CheckItem = styled.label` display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; border-bottom: 1px solid #eee; cursor: pointer; font-size: 14px; color: #444; &:last-child { border-bottom: none; } &:hover { background: #f3f4f6; } input { width: 18px; height: 18px; accent-color: #a855f7; cursor: pointer; } `;