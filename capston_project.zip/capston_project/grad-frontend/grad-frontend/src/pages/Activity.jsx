import { useState } from 'react';
import styled from 'styled-components';

const Activity = () => {
  const [activeTab, setActiveTab] = useState('전체');

  const activities = [
    { id: 1, type: "공모전", title: "대학생 IT 창업경진대회", organizer: "중소벤처기업부", desc: "IT 기술 기반 창업 아이디어 공모전.", deadline: "2026-02-28", team: "3~5인 팀", tags: ["#창업", "#IT"] },
    { id: 2, type: "공모전", title: "공개SW 컨트리뷰톤", organizer: "정보통신산업진흥원", desc: "오픈소스 프로젝트 기여 프로그램.", deadline: "2026-03-15", team: "개인/팀", tags: ["#오픈소스", "#GitHub"] },
    { id: 3, type: "대외활동", title: "GDSC 5기 모집", organizer: "Google", desc: "Google 대학생 개발자 커뮤니티.", deadline: "상시 모집", team: "개인", tags: ["#Google", "#커뮤니티"] },
    { id: 4, type: "자격증", title: "AWS Solutions Architect", organizer: "AWS", desc: "클라우드 아키텍처 설계 전문가.", deadline: "상시", team: "", tags: ["#AWS", "#자격증"] },
    { id: 5, type: "자격증", title: "정보처리기사", organizer: "산업인력공단", desc: "SW 개발 필수 자격증.", deadline: "2026-04-30", team: "", tags: ["#필수", "#국가자격증"] },
  ];

  const trends = [
    { category: "채용", title: "AI 개발자 수요 급증", desc: "머신러닝 개발자 연봉 20% 상승...", source: "Tech News", date: "01-09" },
    { category: "기술", title: "Kubernetes 필수 시대", desc: "백엔드 개발자 필수 스킬 등극...", source: "Dev Weekly", date: "01-08" },
    { category: "채용", title: "스타트업 공채 시즌", desc: "시리즈B 이상 스타트업 채용...", source: "Startup KR", date: "01-07" }
  ];

  const filtered = activeTab === '전체' ? activities : activities.filter(i => i.type === activeTab);

  return (
    <MainContent>
      <PageHeader>
        <div><PageTitle>활동 추천</PageTitle><PageSubtitle>맞춤 활동 추천</PageSubtitle></div>
      </PageHeader>

      <FilterContainer>
        {['전체', '공모전', '대외활동', '자격증'].map(tab => (
          <FilterButton key={tab} active={activeTab === tab} onClick={() => setActiveTab(tab)}>
            {tab}
          </FilterButton>
        ))}
      </FilterContainer>
      
      <ContentGrid>
        <LeftColumn>
          <SectionHeader>추천 활동</SectionHeader>
          {filtered.map(item => (
            <ActivityCard key={item.id}>
              <CardHeader>
                <IconWrapper type={item.type}>{item.type === '공모전' ? '🏆' : item.type === '자격증' ? '🏅' : '👥'}</IconWrapper>
                <CardInfo><CardTitle>{item.title}</CardTitle><CardOrganizer>{item.organizer}</CardOrganizer></CardInfo>
                <Badge type={item.type}>{item.type}</Badge>
              </CardHeader>
              <CardDesc>{item.desc}</CardDesc>
              <MetaInfo><span>📅 {item.deadline}</span>{item.team && <span>👥 {item.team}</span>}</MetaInfo>
              <TagRow><Tags>{item.tags.map((t,i)=><Tag key={i}>{t}</Tag>)}</Tags><DetailButton>보기 ↗</DetailButton></TagRow>
            </ActivityCard>
          ))}
        </LeftColumn>
        <RightColumn>
          <SectionHeader style={{color:'#7e22ce'}}>📈 산업 동향</SectionHeader>
          {trends.map((t, i) => (
            <TrendCard key={i}>
              <TrendCategory>{t.category}</TrendCategory>
              <TrendTitle>{t.title}</TrendTitle>
              <TrendDesc>{t.desc}</TrendDesc>
              <TrendFooter><span>{t.source}</span><span>{t.date}</span></TrendFooter>
            </TrendCard>
          ))}
        </RightColumn>
      </ContentGrid>
    </MainContent>
  );
};

export default Activity;

// 스타일 컴포넌트
const MainContent = styled.div` flex: 1; padding: 40px; overflow-y: auto; height: 100vh; box-sizing: border-box; `;
const PageHeader = styled.div` margin-bottom: 30px; `;
const PageTitle = styled.h2` font-size: 28px; color: #333; font-weight: bold; margin-bottom: 8px; `;
const PageSubtitle = styled.p` font-size: 16px; color: #666; `;
const FilterContainer = styled.div` display: flex; gap: 10px; margin-bottom: 30px; `;
const FilterButton = styled.button` padding: 10px 20px; border-radius: 20px; font-weight: bold; cursor: pointer; border: 1px solid ${props=>props.active?'#a855f7':'#eee'}; background: ${props=>props.active?'#a855f7':'white'}; color: ${props=>props.active?'white':'#666'}; `;
const ContentGrid = styled.div` display: grid; grid-template-columns: 2fr 1fr; gap: 30px; `;
const LeftColumn = styled.div` display: flex; flex-direction: column; gap: 20px; `;
const RightColumn = styled.div` display: flex; flex-direction: column; gap: 20px; `;
const SectionHeader = styled.h3` font-size: 18px; color: #333; margin-bottom: 15px; font-weight: bold; `;
const ActivityCard = styled.div` background: white; border-radius: 16px; padding: 25px; border: 1px solid #eee; transition: all 0.2s; &:hover { transform: translateY(-3px); } `;
const CardHeader = styled.div` display: flex; align-items: flex-start; gap: 15px; margin-bottom: 15px; `;
const IconWrapper = styled.div` width: 48px; height: 48px; border-radius: 12px; display: flex; justify-content: center; align-items: center; font-size: 24px; flex-shrink: 0; background: ${props=>props.type==='공모전'?'#fef9c3':props.type==='자격증'?'#dcfce7':'#dbeafe'}; `;
const CardInfo = styled.div` flex: 1; `;
const CardTitle = styled.h4` font-size: 18px; font-weight: bold; margin-bottom: 5px; color: #333; `;
const CardOrganizer = styled.div` font-size: 13px; color: #888; `;
const Badge = styled.span` padding: 4px 10px; border-radius: 8px; font-size: 12px; font-weight: bold; background: ${props=>props.type==='공모전'?'#fef9c3':props.type==='자격증'?'#dcfce7':'#dbeafe'}; color: ${props=>props.type==='공모전'?'#854d0e':props.type==='자격증'?'#166534':'#1e40af'}; `;
const CardDesc = styled.p` font-size: 15px; color: #555; line-height: 1.5; margin-bottom: 20px; `;
const MetaInfo = styled.div` display: flex; gap: 15px; font-size: 14px; color: #666; margin-bottom: 20px; span { display: flex; align-items: center; gap: 5px; } `;
const TagRow = styled.div` display: flex; justify-content: space-between; align-items: center; `;
const Tags = styled.div` display: flex; gap: 6px; `;
const Tag = styled.span` background: #f3f4f6; color: #666; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 500; `;
const DetailButton = styled.button` background: white; border: 1px solid #ddd; padding: 8px 16px; border-radius: 8px; font-size: 13px; color: #555; cursor: pointer; font-weight: bold; &:hover { background: #f9fafb; } `;
const TrendCard = styled.div` background: white; border-radius: 16px; padding: 20px; border: 1px solid #eee; `;
const TrendCategory = styled.div` color: #a855f7; font-size: 12px; font-weight: bold; margin-bottom: 8px; `;
const TrendTitle = styled.h4` font-size: 16px; font-weight: bold; margin-bottom: 10px; color: #333; `;
const TrendDesc = styled.p` font-size: 13px; color: #666; margin-bottom: 15px; `;
const TrendFooter = styled.div` display: flex; justify-content: space-between; font-size: 12px; color: #999; `;